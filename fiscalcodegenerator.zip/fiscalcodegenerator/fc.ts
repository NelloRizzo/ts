import { IFiscalCodeService, PersonalData, Gender, FiscalCodeService } from "./fiscalcodeservice";
import { FileCityService } from "./cityservice";
function calculateFiscalCode(service: IFiscalCodeService): void {
    let p = new PersonalData("silViO",
        "Berlusconi",
        new Date('1936-09-29'),
        Gender.Male,
        "milano", "mi")
    service.generateFiscalCode(p, f => console.log(p, f))
}

let s = new FiscalCodeService(new FileCityService('./comuni.csv'))
calculateFiscalCode(s)