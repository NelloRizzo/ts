/*
La mia applicazione, prevede un controller che soddisfa la richiesta
/
proponendo all'utente un form in cui può inserire due numeri e la
richiesta di un'operazione
e una richiesta
/result
alla quale il form invia i dati per la produzione dell'operazione richiesta
*/

import { Application } from "express";
import express from "express"

const app = express();

app.use(express.urlencoded({ extended: true }))
app.get('/', (req, res) => {
    res.send(' \
       <!DOCTYPE html><html lang="it"><head></head><body>\
          <h1>Calcolatrice</h1>\
          <form method="get" action="/result">\
            <div>\
                <label for="first">Primo operando</label>\
                <input type="number" name="first" id="first">\
            </div>\
            <div>\
                <label for="operation">Operatore</label>\
                <select name="operation" id="operation">\
                    <option value="+">&plus;</option>\
                    <option value="-">&minus;</option>\
                    <option value="*">&times;</option>\
                    <option value="/">&divide;</option>\
                </select>\
            \
            </div>\
            <div>\
                <label for="second">Secondo operando</label>\
                <input type="number" name="second" id="second">\
            </div>\
            <div>\
                <button type="submit">Calcola</button>\
            </div>\
          </form>\
       </body></html>')
})
app.get('/post', (req, res) => {
    res.send(' \
       <!DOCTYPE html><html lang="it"><head></head><body>\
          <h1>Calcolatrice</h1>\
          <form method="post" action="/result">\
            <div>\
                <label for="first">Primo operando</label>\
                <input type="number" name="first" id="first">\
            </div>\
            <div>\
                <label for="operation">Operatore</label>\
                <select name="operation" id="operation">\
                    <option value="+">&plus;</option>\
                    <option value="-">&minus;</option>\
                    <option value="*">&times;</option>\
                    <option value="/">&divide;</option>\
                </select>\
            \
            </div>\
            <div>\
                <label for="second">Secondo operando</label>\
                <input type="number" name="second" id="second">\
            </div>\
            <div>\
                <button type="submit">Calcola</button>\
            </div>\
          </form>\
       </body></html>')
})

const calculate = (f: number, s: number, o: string): string => {
    const res = (o == "+") ? f + s : (o == '-') ? f - s : (o == '*') ? f * s : f / s
    return ` \
    <!DOCTYPE html><html lang="it"><head></head><body>\
       <h1>Calcolatrice</h1>\
        ${f} ${o} ${s} &equals; ${res}
    </body></html>`
}
app.get("/result", (req, res) => {
    const first = parseInt(req.query.first?.toString() ?? '0')
    const second = parseInt(req.query.second?.toString() ?? '0')
    const operation = req.query.operation?.toString() ?? '='

    res.send(calculate(first, second, operation))
})
app.post("/result", (req, res) => {
    const first = parseInt(req.body.first?.toString() ?? '0')
    const second = parseInt(req.body.second?.toString() ?? '0')
    const operation = req.body.operation?.toString() ?? '='

    res.send(calculate(first, second, operation))
})

app.listen(8888, () => console.log("Server ready"))