fetch("https://jsonplaceholder.typicode.com/posts")
    .then(resp => {
        if (!resp.ok) {
            console.log("Error")
        }
        return resp.json()
    })
    .then(resp => console.log(resp))
