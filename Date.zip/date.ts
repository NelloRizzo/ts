// Occorre implementare un sistema di gestione
// delle operazioni tra date.
// In particolare si vuole gestire il concetto di data
// e dare la possibilità di aggiungere (o sottrarre)
// da esso giorni, mesi, anni, ottenendo una nuova data.
export class MyDate {
    private _year!: number
    private _month!: number
    private _day!: number

    public get year(): number { return this._year }
    public get month(): number { return this._month }
    public get day(): number { return this._day }

    public constructor(year?: number, month?: number, day?: number) {
        let now = new Date()
        this._day = day || now.getDate()
        this._month = month || now.getMonth() + 1
        this._year = year || now.getFullYear()
        if (!isValidDate(this._year, this._month, this._day))
            throw new InvalidDateException(this._year, this._month, this._day)
    }

    private formatDate(fmt: string): string {
        return fmt.replaceAll('dd', padNumber(this.day, 2))
            .replaceAll('mm', padNumber(this.month, 2))
            .replaceAll('yy', padNumber(this.year, 4))
            .replaceAll('d', this.day.toString())
            .replaceAll('m', this.month.toString())
            .replaceAll('y', this.year.toString())
    }

    public toString(fmt?: string): string {
        if (fmt) return this.formatDate(fmt)

        return `${padNumber(this.day, 2)}/${padNumber(this.month, 2)}/${padNumber(this.year, 4)}`
    }
    public addYears(years: number = 1): MyDate {
        return new MyDate(this.year + years, this.month, this.day)
    }
    public addMonths(months: number = 1): MyDate {
        if (months < 0) return this.subMonths(-months)
        let d = this.day
        let m = this.month
        let y = this.year
        while (months--) {
            if (m == 12) {
                m = 1
                y++
            }
            else
                m++
        }
        return new MyDate(y, m, d)
    }
    public subMonths(months: number = 1): MyDate {
        if (months < 0) return this.addMonths(-months)
        let d = this.day
        let m = this.month
        let y = this.year
        while (months--) {
            if (m == 1) {
                m = 12
                y--
            }
            else
                m--
        }
        return new MyDate(y, m, d)
    }

    public addDays(days: number = 1): MyDate {
        if (days < 0) return this.subDays(-days)
        let d = this.day
        let m = this.month
        let y = this.year
        while (days--) {
            let md = monthDays(y)
            if (d > md[m - 1]) {
                d = 1
                if (m == 12) {
                    m = 1
                    y++
                }
                else
                    m++
            }
            else
                d++
        }
        return new MyDate(y, m, d)
    }

    public subDays(days: number = 1): MyDate {
        if (days < 0) return this.addDays(-days)
        let d = this.day
        let m = this.month
        let y = this.year
        while (days--) {
            let md = monthDays(y)
            if (d == 1) {
                if (m == 1) {
                    m = 12
                    y--
                }
                else
                    m--
                md = monthDays(y)
                d = md[m - 1]
            }
            else
                d--
        }
        return new MyDate(y, m, d)
    }
}

let monthDays = (y: number): number[] => [31, 28 + (isLeapYear(y) ? 1 : 0), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
let isLeapYear = (y: number): boolean => y % 4 == 0 && y % 400 != 0
function isValidDate(year: number, month: number, day: number): boolean {
    if (month < 1 || month > 12) return false
    let md = monthDays(year)
    return day > 0 && day <= md[month - 1]
}

export function padNumber(n: number, len: number = 1, pad: string = '0'): string {
    let ns = n.toString()
    while (ns.length < len) ns = pad + ns
    return ns
}
export class DateException { }
export class InvalidDateException extends DateException {
    public constructor(public year: number, public month: number, public day: number) {
        super()
    }
}
