class PrimeNumberTester {
    private _value: number = 0;
    public get value(): number { return this._value }

    public constructor(value: number) {
        this._value = value
    }

    private checkPrimeNumber(): boolean {
        for (let i = 2; i < this._value / 2; ++i) {
            if (this._value % i == 0) return false
        }
        return true
    }

    public isPrime() {
        console.log("check for", this.value)
        return new Promise<boolean>(
            (resolve, reject) => {
                if (this._value != Math.trunc(this._value))
                    reject("Number must be integer")
                else {
                    setTimeout(() => {
                        let c = this.checkPrimeNumber()
                        resolve(c)
                    }, 100);
                }
            })
    }

}

let t = new PrimeNumberTester(8431934.8)
t.isPrime()
    .then(r => { console.log("promise is fulfilled =", r); return r })
    .then(x => console.log(x ? "Il numero è primo" : "Il numero non è primo"))
    .catch(r => console.log("promise is rejected =", r))

console.log("application still working")

const getResult = async () => {
    try {
        const resp = await t.isPrime()
        console.log("async", resp)
    } catch (e) {
        console.log("async error", e)
    }
}
getResult()
console.log("application still working also after async call")
