//let fs = require('fs')
import * as fs from 'fs'

export class City {
    public constructor(public name: string,
        public acronym: string,
        public id: number,
        public code: string) { }
}

export type CityServiceCallback = (c: City[]) => void

export interface ICityService {
    readCities(callback: CityServiceCallback): void
}

export class FileCityService implements ICityService {
    public constructor(private path: string) { }

    public readCities(callback: CityServiceCallback): void {

        fs.readFile(this.path, 'latin1',
            (error, data) => {
                let cities = data.split('\n')
                cities.shift()
                var result = cities
                    .map((i, v) => {
                        let p = i.split(';')
                        return new City(p[0]?.trim().replaceAll('"', ""),
                            p[1]?.trim().replaceAll('"', ""),
                            parseInt(p[2]),
                            p[3]?.trim().replaceAll('"', ""))
                    })
                    .filter(c => c.id)
                //.forEach((v, i) => console.log(i, v))
                callback(result)
            })
    }
}


