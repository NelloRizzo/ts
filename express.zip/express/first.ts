import { Request, Response, Application } from 'express'
import express from 'express'
import bodyParser from 'body-parser'

const app: Application = express()

let v: number = 1

const port = 8888

app
    .use(express.json())
    .use(bodyParser.text({ type: "*/*" }))
    .use((req, res, next) => {
        console.log(req.url + " at " + new Date())
        res.header('OutDate', JSON.stringify(new Date()))
        next()
    })
    ;

app.get('/', (req, res) => {
    res.send(`Welcome ${v++}`)
})

app.get('/date', (req: Request, res: Response) => {
    const date = new Date()
    let out = ""
    if (req.query['msg'])
        out += req.query['msg']
    if (req.query['fmt']) {
        let fmt = req.query['fmt']
        let day = date.getDate()
        let month = date.getMonth()
        let year = date.getFullYear()
        res.send(out + " " + fmt.toString()
            .replaceAll('d', `${day}`).replaceAll('m', `${month}`).replaceAll('y', `${year}`))
        return
    }
    res.send(out + new Date())
})

app.get('/greetings/:name/lang/:lang?', (req, res) => {
    const welcome = req.params.lang == 'it' ? 'Buongiorno' : 'Welcome'
    res.send(`${welcome}, ${req.params.name}!`)
})

app.post('/', (req, res) => {
    res.send("Messaggio ricevuto: " + JSON.stringify(req.body))
})

app.get(/nome_.*/, (req, res) => {
    res.send(`Nome: ${req.url.substring(5)}`)
})
app.get(/add_\d+_\d+$/, (req, res) => {
    const re = /add_(?<first>\d+)_(?<second>\d+)/
    const result = re.exec(req.url)
    console.log(result)
    res.send(`Risultato: ${parseInt(result?.at(1) ?? '0') + parseInt(result?.at(2) ?? '0')}`)
})
app.listen(port, () => console.log(`Express is listening on port ${port}...`))