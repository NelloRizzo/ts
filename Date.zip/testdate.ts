import * as date from './date';
import { MyDate as Date, InvalidDateException } from './date';

var d = new Date()

console.log("oggi", d)
console.log("mese attuale", d.month)
console.log("fra 20 giorni", d.addDays(20))
console.log("ieri", d.subDays())
var s: string = d.toString()
console.log(s)
console.log(d.toString('dd - mm - y'))

console.log(date.padNumber(1, 10, 'X'))
try {
    new Date(2023, 2, 30)
} catch (e: unknown) {
    if (e instanceof InvalidDateException) {
        let error = e as InvalidDateException
        console.log(`Data non valida ${error.day}, ${error.month}, ${error.year}`)
    }
    else
        throw e
}