import { ICityService, City } from "./cityservice"

export enum Gender {
    Male = 0,
    Female = 40
}

export class PersonalData {
    public constructor(
        public firstName: string,
        public lastName: string,
        public birthday: Date,
        public gender: Gender,
        public birthCity: string,
        public birthProvince: string
    ) { }
}

export type FiscalCodeGeneratorCallback = (fiscalCode: string) => void
export interface IFiscalCodeService {
    generateFiscalCode(p: PersonalData, callback: FiscalCodeGeneratorCallback): void
}

class FiscalCodeServiceV1 implements IFiscalCodeService {
    public constructor(private cities: ICityService) { }

    public generateFiscalCode(p: PersonalData, callback: (fiscalCode: string) => void): void {
        let fc = handleLastName(p.lastName)
            + handleFirstName(p.firstName)
            + handleBirthday(p.birthday, p.gender)

        this.cities.readCities(c => {
            let city = c
                .filter(i => i.name.toLowerCase() == p.birthCity.toLowerCase() && i.acronym.toLowerCase() == p.birthProvince.toLowerCase())
                .pop()
            fc += city?.code || "X000"
            let code = `${fc}${calculateCheckCode(fc)}`
            callback(code)
        })
    }
}

class ConsonantsVowels {
    public consonants: string = ""
    public vowels: string = ""

    public constructor(text: string) {
        text = text.toUpperCase()
        for (let i = 0; i < text.length; ++i) {
            let ch = text.charAt(i)
            if (ch >= 'A' && ch <= 'Z') {
                if ("AEIUO".indexOf(ch) < 0)
                    this.consonants += ch
                else
                    this.vowels += ch
            }
        }
    }
}

function handleLastName(l: string): string {
    let cv = new ConsonantsVowels(l)
    let [c, v] = [cv.consonants, cv.vowels]
    return `${c}${v}XXX`.substring(0, 3)
}
function handleFirstName(f: string): string {
    let cv = new ConsonantsVowels(f)
    let [c, v] = [cv.consonants, cv.vowels]
    if (c.length > 3) c = c[0] + c.substring(2)
    return `${c}${v}XXX`.substring(0, 3)
}
function handleBirthday(bd: Date, g: Gender): string {
    let [y, m, d] = [bd.getFullYear(), bd.getMonth(), `00${bd.getDate() + g}`.slice(-2)]
    return `${y % 100}${"ABCDEHLMPRST"[m - 1]}${d}`
}
function calculateCheckCode(fc: string): string {
    const ODDS = [1, 0, 5, 7, 9, 13, 15, 17, 19, 21, 2, 4, 18, 20, 11, 3, 6, 8, 12, 14, 16, 10, 22, 25, 24, 23]
    const ZERO = '0'.charCodeAt(0)
    const A = 'A'.charCodeAt(0)
    let sum: number = 0
    for (let i = 0; i < 15; ++i) {
        let ch = fc.charAt(i)
        let depl = ch.charCodeAt(0) - (ch >= '0' && ch <= '9' ? ZERO : A)
        sum += i % 2 == 0 ? ODDS[depl] : depl
    }
    return String.fromCharCode(sum % 26 + A)
}


export { FiscalCodeServiceV1 as FiscalCodeService }